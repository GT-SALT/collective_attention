# Hurricane path data
Downloaded from here: https://www.nhc.noaa.gov/data/tcr/index.php?season=2017&basin=atl

- Harvey: https://www.nhc.noaa.gov/gis/best_track/al092017_best_track.kmz
- Irma: https://www.nhc.noaa.gov/gis/best_track/al112017_best_track.kmz
- Maria: https://www.nhc.noaa.gov/gis/best_track/al152017_best_track.kmz